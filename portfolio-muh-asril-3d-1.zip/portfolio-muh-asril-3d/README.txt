PORTOFOLIO MAHASISWA 3D — MUH ASRIL

Isi folder:
- index.html: website responsif; HTML, CSS, dan JavaScript dalam satu file.
- logo-kampus.jpg: logo kampus yang diberikan.
- logo-sman10-pinrang.jpg: logo SMA Negeri 10 Pinrang yang diberikan.
- logo-smp.jpg: logo SMP yang diberikan; nama sekolah belum diketahui.
- profile.jpg: tambahkan foto profil sendiri dengan nama ini jika ingin ditampilkan.

Data yang dimasukkan:
- Nama: MUH ASRIL
- Nama panggilan: ASR
- Tempat/tanggal lahir: Kessie, 16 Desember 2007
- Domisili: Pinrang
- Kampus: Institut Teknologi Bacharuddin Jusuf Habibie
- Program studi: Teknik Elektro
- SMA: SMA Negeri 10 Pinrang, lulus 2026
- Email: muh.asril16122007@gmail.com
- WhatsApp: 0882020251378
- Instagram: @m_asr16
- Media sosial lain yang diberikan: @m.....ril16 (jenis akun belum dipastikan)

Bagian keahlian, hobi, prestasi, pengalaman, dan nama SMP belum diisi karena datanya belum diberikan. Website memakai placeholder dan tidak mengarang informasi.

Cara membuka:
1. Ekstrak ZIP.
2. Buka index.html melalui editor kode atau browser.
3. Letakkan foto profil bernama profile.jpg di folder yang sama.
4. Periksa semua data sebelum dipublikasikan.

Publikasi gratis via GitHub Pages:
1. Masuk ke https://github.com/
2. Buat repository bernama portfolio-mahasiswa.
3. Unggah seluruh file dalam folder ini.
4. Buka Settings > Pages.
5. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.
6. Setelah proses selesai, situs biasanya tersedia di https://USERNAME.github.io/portfolio-mahasiswa/

Form kontak membuka aplikasi email (mailto), bukan mengirim melalui server.
